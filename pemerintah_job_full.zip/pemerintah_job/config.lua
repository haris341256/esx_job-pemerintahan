Config = {}

Config.KantorPresiden = vector3(-521.14, -178.42, 38.22)
Config.BossMenuLocation = vector3(-520.1, -174.5, 38.22)
Config.PintuKantor = {
    {coords = vector3(-523.8, -177.4, 38.22), heading = 90.0, locked = true}
}

Config.Vehicles = {
    {label = "Limousine", model = "stretch"},
    {label = "SUV Dinas", model = "baller6"},
    {label = "Helikopter", model = "frogger"}
}

Config.Uniforms = {
    presiden = {
        male = { ['tshirt_1'] = 15, ['torso_1'] = 24, ['pants_1'] = 10, ['shoes_1'] = 10 },
        female = { ['tshirt_1'] = 14, ['torso_1'] = 20, ['pants_1'] = 6, ['shoes_1'] = 6 }
    },
    pengawal = {
        male = { ['tshirt_1'] = 15, ['torso_1'] = 55, ['pants_1'] = 24, ['shoes_1'] = 25 },
        female = { ['tshirt_1'] = 14, ['torso_1'] = 49, ['pants_1'] = 34, ['shoes_1'] = 27 }
    }
}
