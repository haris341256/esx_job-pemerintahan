RegisterCommand("vote", function()
    ESX.TriggerServerCallback("pemerintah:getCalonList", function(calonList)
        local elements = {}
        for _, calon in pairs(calonList) do
            table.insert(elements, {label = calon.name, value = calon.identifier})
        end
        ESX.UI.Menu.Open("default", GetCurrentResourceName(), "vote_menu", {
            title = "Pilih Calon Presiden",
            align = "top-left",
            elements = elements
        }, function(data, menu)
            TriggerServerEvent("pemerintah:submitVote", data.current.value)
            ESX.ShowNotification("Suara berhasil dikirim.")
            menu.close()
        end, function(data, menu)
            menu.close()
        end)
    end)
end)
