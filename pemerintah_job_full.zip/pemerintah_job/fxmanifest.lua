fx_version 'cerulean'
game 'gta5'

description 'Job Pemerintah - Presiden & Staff'
author 'ChatGPT'

shared_script 'config.lua'
client_scripts {
    'client.lua',
    'vote.lua'
}
server_script 'server.lua'

dependency 'es_extended'
