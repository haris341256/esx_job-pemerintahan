ESX = exports['es_extended']:getSharedObject()

RegisterNetEvent('pemerintah_job:setDoorStatus')
AddEventHandler('pemerintah_job:setDoorStatus', function(index, locked)
    TriggerClientEvent('pemerintah_job:updateDoorStatus', -1, index, locked)
end)

TriggerEvent('esx_society:registerSociety', 'pemerintah', 'Pemerintah', 'society_pemerintah', 'society_pemerintah', 'society_pemerintah', {type = 'public'})

RegisterNetEvent('pemerintah:transferBudget')
AddEventHandler('pemerintah:transferBudget', function(targetSociety, amount)
    local xPlayer = ESX.GetPlayerFromId(source)
    TriggerEvent('esx_addonaccount:getSharedAccount', 'society_pemerintah', function(society)
        if society.money >= amount then
            society.removeMoney(amount)
            TriggerEvent('esx_addonaccount:getSharedAccount', 'society_'..targetSociety, function(target)
                if target then
                    target.addMoney(amount)
                    xPlayer.showNotification("Dana berhasil ditransfer ke " .. targetSociety)
                else
                    xPlayer.showNotification("Target society tidak ditemukan.")
                end
            end)
        else
            xPlayer.showNotification("Dana negara tidak mencukupi.")
        end
    end)
end)

RegisterCommand("daftarcalon", function(source)
    local xPlayer = ESX.GetPlayerFromId(source)
    MySQL.Async.execute("REPLACE INTO pemilu_calon (identifier, name) VALUES (@id, @name)", {
        ["@id"] = xPlayer.identifier,
        ["@name"] = GetPlayerName(source)
    }, function()
        TriggerClientEvent("esx:showNotification", source, "Kamu terdaftar sebagai calon Presiden!")
    end)
end, false)

ESX.RegisterServerCallback("pemerintah:getCalonList", function(src, cb)
    MySQL.Async.fetchAll("SELECT * FROM pemilu_calon", {}, function(result)
        cb(result)
    end)
end)

RegisterNetEvent("pemerintah:submitVote")
AddEventHandler("pemerintah:submitVote", function(voteFor)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    MySQL.Async.execute("REPLACE INTO pemilu_vote (identifier, vote_for) VALUES (@id, @vote)", {
        ["@id"] = xPlayer.identifier,
        ["@vote"] = voteFor
    })
end)

RegisterCommand("hitungvote", function(src)
    MySQL.Async.fetchAll([[
        SELECT vote_for, COUNT(*) as jumlah
        FROM pemilu_vote
        GROUP BY vote_for
        ORDER BY jumlah DESC
        LIMIT 1
    ]], {}, function(result)
        if result[1] then
            local winnerId = result[1].vote_for
            MySQL.Async.execute("UPDATE users SET job = 'pemerintah', job_grade = 0 WHERE identifier = @id", {
                ["@id"] = winnerId
            }, function()
                print("Pemenang pemilu diangkat sebagai Presiden.")
            end)
        end
    end)
end, true)
