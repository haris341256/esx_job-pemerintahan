CREATE TABLE IF NOT EXISTS `pemilu_calon` (
  `identifier` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`identifier`)
);

CREATE TABLE IF NOT EXISTS `pemilu_vote` (
  `identifier` varchar(50) NOT NULL,
  `vote_for` varchar(50) NOT NULL
);
