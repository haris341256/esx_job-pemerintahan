-- client.lua
ESX = exports['es_extended']:getSharedObject()
local isInPresiden = false

CreateThread(function()
    local blip = AddBlipForCoord(Config.KantorPresiden)
    SetBlipSprite(blip, 419)
    SetBlipDisplay(blip, 4)
    SetBlipScale(blip, 0.8)
    SetBlipColour(blip, 3)
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Kantor Presiden")
    EndTextCommandSetBlipName(blip)
end)

function OpenPresidenMenu()
    ESX.UI.Menu.CloseAll()
    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'presiden_menu', {
        title = 'Menu Pemerintah',
        align = 'top-left',
        elements = {
            {label = "Ganti Seragam", value = 'uniform'},
            {label = "Spawn Kendaraan", value = 'vehicle'},
            {label = "Transfer Anggaran Negara", value = 'transfer_budget'}
        }
    }, function(data, menu)
        if data.current.value == 'uniform' then
            SetUniform()
        elseif data.current.value == 'vehicle' then
            OpenVehicleMenu()
        elseif data.current.value == 'transfer_budget' then
            OpenBudgetTransfer()
        end
    end, function(data, menu)
        menu.close()
    end)
end

function SetUniform()
    ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin)
        TriggerEvent('skinchanger:getSkin', function(currentSkin)
            local job = ESX.GetPlayerData().job.name
            local grade = ESX.GetPlayerData().job.grade
            local uniform = grade == 0 and Config.Uniforms.presiden or Config.Uniforms.pengawal
            if skin.sex == 0 then
                TriggerEvent('skinchanger:loadClothes', skin, uniform.male)
            else
                TriggerEvent('skinchanger:loadClothes', skin, uniform.female)
            end
        end)
    end)
end

function OpenVehicleMenu()
    local elements = {}
    for _,v in pairs(Config.Vehicles) do
        table.insert(elements, {label = v.label, value = v.model})
    end
    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'vehicle_menu', {
        title = 'Pilih Kendaraan',
        align = 'top-left',
        elements = elements
    }, function(data, menu)
        ESX.Game.SpawnVehicle(data.current.value, GetEntityCoords(PlayerPedId()), 90.0, function(vehicle)
            TaskWarpPedIntoVehicle(PlayerPedId(), vehicle, -1)
        end)
    end, function(data, menu)
        menu.close()
    end)
end

function OpenBudgetTransfer()
    ESX.UI.Menu.Open('dialog', GetCurrentResourceName(), 'target_society', {
        title = "Masukkan nama society (contoh: police)"
    }, function(data1, menu1)
        local targetSociety = data1.value
        ESX.UI.Menu.Open('dialog', GetCurrentResourceName(), 'amount', {
            title = "Jumlah dana yang ingin dikirim"
        }, function(data2, menu2)
            local amount = tonumber(data2.value)
            if amount then
                TriggerServerEvent('pemerintah:transferBudget', targetSociety, amount)
                ESX.ShowNotification("Transfer berhasil.")
                menu1.close()
                menu2.close()
            else
                ESX.ShowNotification("Jumlah tidak valid.")
            end
        end, function(data2, menu2) menu2.close() end)
    end, function(data1, menu1) menu1.close() end)
end

-- Interaksi lokasi menu
CreateThread(function()
    while true do
        Wait(0)
        local coords = GetEntityCoords(PlayerPedId())
        if #(coords - Config.KantorPresiden) < 2.0 then
            ESX.ShowHelpNotification("Tekan ~INPUT_CONTEXT~ untuk membuka menu Pemerintah")
            if IsControlJustReleased(0, 38) then
                OpenPresidenMenu()
            end
        end
        if #(coords - Config.BossMenuLocation) < 2.0 and ESX.GetPlayerData().job.grade == 0 then
            ESX.ShowHelpNotification("Tekan ~INPUT_CONTEXT~ untuk membuka ~b~Boss Menu")
            if IsControlJustReleased(0, 38) then
                TriggerEvent('esx_society:openBossMenu', 'pemerintah', function(data, menu) menu.close() end, {wash = false})
            end
        end
    end
end)

-- Pintu akses
local pintuStatus = {}
RegisterNetEvent('pemerintah_job:updateDoorStatus')
AddEventHandler('pemerintah_job:updateDoorStatus', function(index, locked)
    Config.PintuKantor[index].locked = locked
end)

CreateThread(function()
    while true do
        Wait(500)
        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)
        for i, door in pairs(Config.PintuKantor) do
            local dist = #(coords - door.coords)
            if dist < 1.5 then
                DrawText3D(door.coords, "[E] " .. (door.locked and "~r~Terkunci" or "~g~Terbuka"))
                if IsControlJustReleased(0, 38) then
                    if ESX.GetPlayerData().job.name == "pemerintah" and ESX.GetPlayerData().job.grade == 0 then
                        door.locked = not door.locked
                        TriggerServerEvent('pemerintah_job:setDoorStatus', i, door.locked)
                    else
                        ESX.ShowNotification("~r~Hanya Presiden yang bisa membuka pintu ini.")
                    end
                end
            end
        end
    end
end)

function DrawText3D(coords, text)
    local onScreen, _x, _y = World3dToScreen2d(coords.x, coords.y, coords.z)
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x, _y)
end
